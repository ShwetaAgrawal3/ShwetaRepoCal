import React, { useState } from 'react';
import './ProductSelectionModal.css';
// import ModalView from './ModalV1/modalView'; 
import ModalV2 from './ModalV1/modalV2';

const ProductSelectionModal = ({ onClose, onProductToggle, selectedProducts ,setIsTileModalOpend,handleClose}) => {
  const [tempSelectedProducts, setTempSelectedProducts] = useState([...selectedProducts]);
 

  const handleOverlayClick = (e) => {
    if (e.target.className === 'tile-modal-overlay') {
      handleSubmit();
    }
  };

  const handleProductClick = (product) => {
    setTempSelectedProducts((prevSelectedProducts) =>
      prevSelectedProducts.includes(product)
        ? prevSelectedProducts.filter((p) => p !== product)
        : [...prevSelectedProducts, product]
    );
  };

  const handleSubmit = () => {
    const newSelectedProducts = [...tempSelectedProducts];
    selectedProducts.forEach(product => {
      if (!newSelectedProducts.includes(product)) {
        onProductToggle(product);
      }
    });
    newSelectedProducts.forEach(product => {
      if (!selectedProducts.includes(product)) {
        onProductToggle(product);
      }
    });
    onClose();
    if(selectedProducts.length>0){
      setIsTileModalOpend((prev)=>!prev)
    }
  };

  const products = [
    { product: 'CEComponent', displayText: 'CE Component' },
    { product: 'CloudStorageComponent', displayText: 'Cloud Storage' },
    { product: 'DBComponent', displayText: 'DB' },
    { product: 'BQComponent', displayText: 'BQ' },
    { product: 'DFlowComponent', displayText: 'Dataflow' },
    { product: 'GCLBComponent', displayText: 'Google Cloud Load Balancer' },
    { product: 'LStorageComponent', displayText: 'Log Storage' },
    { product: 'FilestoreComponent', displayText: 'Filestore' },
    { product: 'Product8', displayText: 'Product 8' },
  ];

  return (
    <ModalV2
      text="Select an Option"
      buttonText="Submit"
      handleOverlayClick={handleOverlayClick}
      handleSubmit={handleSubmit}
      classNames={'modalSize'}
      onClose={handleClose}
      containerClass={'container'}
    >

      {products.map(({ product, displayText }) => (
        <button
          key={product}
          className={`tile-button ${tempSelectedProducts.includes(product) ? 'selected' : ''}`}
          onClick={() => handleProductClick(product)}
        >
          {displayText}
        </button>
      ))}
    </ModalV2>
  );
};

export default ProductSelectionModal;
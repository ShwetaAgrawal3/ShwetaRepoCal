import React from 'react'
import './LandingPage.css'

function welcome() {
  return (
    <div className='welcomeBanner'>
      <div className='containerBanner'>
      <div>
text
        </div>
        <div>
image
        </div>
      </div>
       
    </div>
  )
}

export default welcome